package com.example.facecapture

import android.annotation.SuppressLint
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FaceAnalyzer(
    private val context: android.content.Context,
    private val onFaceDetected: (brojLica: Int) -> Unit,
    private val onImageSaved: (imeFajla: String) -> Unit
) : ImageAnalysis.Analyzer {

    companion object {
        private const val TAG = "FaceAnalyzer"
        private const val COOLDOWN_MS = 1500L
        private const val MAX_SLIKA = 10
        private const val MIN_VELICINA_LICA = 0.10f
        private const val CUVAJ_SAMO_LICE = true
        private const val MARGIN = 0.20f
    }

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .setMinFaceSize(MIN_VELICINA_LICA)
            .build()
    )

    private var poslednjaSlikaVreme = 0L
    private var brojSlika = 0
    private val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }
        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                onFaceDetected(faces.size)
                if (faces.isNotEmpty() && mozeDaUslika()) uslikaj(imageProxy, faces[0])
            }
            .addOnFailureListener { e -> Log.e(TAG, "Greska: ${e.message}") }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun mozeDaUslika(): Boolean {
        val sada = System.currentTimeMillis()
        if (brojSlika >= MAX_SLIKA) return false
        if (sada - poslednjaSlikaVreme < COOLDOWN_MS) return false
        poslednjaSlikaVreme = sada
        return true
    }

    private fun uslikaj(imageProxy: ImageProxy, lice: Face) {
        try {
            val bitmap = imageProxy.toBitmap()
            val finalnaSlika = if (CUVAJ_SAMO_LICE)
                iseciLice(bitmap, lice, imageProxy.imageInfo.rotationDegrees)
            else bitmap
            val ime = sacuvajUGaleriju(finalnaSlika)
            if (ime != null) {
                brojSlika++
                Log.i(TAG, "Sacuvano: $ime ($brojSlika/$MAX_SLIKA)")
                onImageSaved(ime)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Greska pri cuvanju: ${e.message}")
        }
    }

    private fun iseciLice(bitmap: Bitmap, lice: Face, rotacija: Int): Bitmap {
        // ML Kit vraca boundingBox u rotiranim koordinatama, pa prvo rotiramo sliku
        val uspravna = if (rotacija != 0) {
            val matrix = android.graphics.Matrix()
            matrix.postRotate(rotacija.toFloat())
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else bitmap
        val bounds: Rect = lice.boundingBox
        val marginX = (bounds.width() * MARGIN).toInt()
        val marginY = (bounds.height() * MARGIN).toInt()
        val x1 = (bounds.left - marginX).coerceAtLeast(0)
        val y1 = (bounds.top - marginY).coerceAtLeast(0)
        val x2 = (bounds.right + marginX).coerceAtMost(uspravna.width)
        val y2 = (bounds.bottom + marginY).coerceAtMost(uspravna.height)
        val sirina = x2 - x1
        val visina = y2 - y1
        if (sirina <= 0 || visina <= 0) return uspravna
        return Bitmap.createBitmap(uspravna, x1, y1, sirina, visina)
    }

    private fun sacuvajUGaleriju(bitmap: Bitmap): String? {
        return try {
            val ime = "lice_${dateFormat.format(Date())}.jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, ime)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceCapture")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val uri = context.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            ) ?: return null
            context.contentResolver.openOutputStream(uri)?.use { outputStream: OutputStream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
            }
            ime
        } catch (e: Exception) {
            Log.e(TAG, "Greska: ${e.message}")
            null
        }
    }

    fun resetuj() {
        brojSlika = 0
        poslednjaSlikaVreme = 0L
    }
}
