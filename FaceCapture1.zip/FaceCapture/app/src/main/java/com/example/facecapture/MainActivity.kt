package com.example.facecapture

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.facecapture.databinding.ActivityMainBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private var faceAnalyzer: FaceAnalyzer? = null
    private var cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
    private var brojSlika = 0
    private val MAX_SLIKA = 10

    private val zahtevZaKameru = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { dozvoljeno ->
        if (dozvoljeno) pokreniKameru()
        else {
            Toast.makeText(this, "Potrebna je dozvola za kameru!", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.switchCameraButton.setOnClickListener {
            cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }
            pokreniKameru()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            pokreniKameru()
        } else {
            zahtevZaKameru.launch(Manifest.permission.CAMERA)
        }
    }

    private fun pokreniKameru() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(binding.previewView.surfaceProvider)
                }

                brojSlika = 0
                azurirajBrojac()

                faceAnalyzer = FaceAnalyzer(
                    context = this,
                    onFaceDetected = { brojLica ->
                        runOnUiThread {
                            binding.statusText.text = if (brojLica > 0)
                                "Lice detektovano ($brojLica)"
                            else "Trazim lice..."
                        }
                    },
                    onImageSaved = { ime ->
                        runOnUiThread {
                            brojSlika++
                            azurirajBrojac()
                            binding.statusText.text = "Sacuvano: $ime"
                            if (brojSlika >= MAX_SLIKA) {
                                Toast.makeText(this, "Dostignut limit od $MAX_SLIKA slika!",
                                    Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                )

                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(cameraExecutor, faceAnalyzer!!) }

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis)
                binding.statusText.text = "Trazim lice..."
            } catch (e: Exception) {
                Toast.makeText(this, "Greska: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun azurirajBrojac() {
        binding.counterText.text = "Slike: $brojSlika / $MAX_SLIKA"
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
