# FaceCapture - Prepoznavanje lica

Android aplikacija koja automatski slika kada detektuje lice.

## Kako otvoriti
1. Otvori Android Studio
2. File -> Open -> izaberi folder FaceCapture
3. Sacekaj da Gradle zavrsi (2-5 min prvi put)
4. Klikni zeleno Run dugme

## Kako napraviti APK
Build -> Build Bundle(s) / APK(s) -> Build APK(s)
APK se nalazi u: app/build/outputs/apk/debug/app-debug.apk

## Kako instalirati na telefon
1. Prebaci app-debug.apk na telefon (USB, email, Google Drive...)
2. Otvori fajl na telefonu
3. Dozvoli "Install from unknown sources" ako pita
4. Instaliraj
